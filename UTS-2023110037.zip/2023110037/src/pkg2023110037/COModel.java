/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pkg2023110037;

import java.sql.Date;

/**
 *
 * @author ASUS
 */
public class COModel {
    private Date TanggalCheckOut;
    private double Total, Bayar;

    public Date getTanggalCheckOut() {
        return TanggalCheckOut;
    }

    public void setTanggalCheckOut(Date TanggalCheckOut) {
        this.TanggalCheckOut = TanggalCheckOut;
    }

    public double getTotal() {
        return Total;
    }

    public void setTotal(double Total) {
        this.Total = Total;
    }

    public double getBayar() {
        return Bayar;
    }

    public void setBayar(double Bayar) {
        this.Bayar = Bayar;
    }

    
    
}

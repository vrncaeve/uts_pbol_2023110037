/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package pkg2023110037;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TextField;

/**
 * FXML Controller class
 *
 * @author ASUS
 */
public class FXML_inputtamuController implements Initializable {

    @FXML
    private TextField txtid;
    @FXML
    private TextField txtnik;
    @FXML
    private TextField txtnama;
    @FXML
    private TextField txttelepon;
    @FXML
    private TextField txtemail;
    @FXML
    private Button btnsave;
    @FXML
    private Button btnclear;
    @FXML
    private Button btnexit;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void saveklik(ActionEvent event) {
        TamuModel s=new TamuModel();
        s.setID(txtid.getText());
        s.setNIK(txtnik.getText());
        s.setNama(txtnama.getText());
        s.setTelepon(txttelepon.getText());
        s.setEmail(txtemail.getText());
        FXMLDocumentController.dttamu.setTamuModel(s);
        if(editdata){
            if(FXMLDocumentController.dttamu.update()){
                          Alert a=new Alert(Alert.AlertType.INFORMATION,"Data berhasil diubah",ButtonType.OK);
               a.showAndWait();   txtid.setEditable(true);        clearklik(event);                
            } else {
               Alert a=new Alert(Alert.AlertType.ERROR,"Data gagal diubah",ButtonType.OK);
               a.showAndWait();                    
            }
        }else if(FXMLDocumentController.dttamu.validasi(s.getID())<=0){
            if(FXMLDocumentController.dttamu.insert()){
               Alert a=new Alert(Alert.AlertType.INFORMATION,"Data berhasil disimpan",ButtonType.OK);
               a.showAndWait();            clearklik(event);
            } else {
               Alert a=new Alert(Alert.AlertType.ERROR,"Data gagal disimpan",ButtonType.OK);
               a.showAndWait();            
            }
        }else{
            Alert a=new Alert(Alert.AlertType.ERROR,"Data sudah ada",ButtonType.OK);
            a.showAndWait();
            txtid.requestFocus();
        }    
            
    }

    @FXML
    private void clearklik(ActionEvent event) {
    }

    @FXML
    private void exitklik(ActionEvent event) {
        System.exit(0);
    }
    
    boolean editdata=false;
    
     public void execute(TamuModel d){
        if(!d.getID().isEmpty()){
          editdata=true;
          txtid.setText(d.getID());
          txtnik.setText(d.getNIK());
          txtnama.setText(d.getNama());
          txttelepon.setText(d.getTelepon());
          txtemail.setText(d.getEmail());
          txtid.setEditable(false);
          txtnik.requestFocus();
        }
    }
    
    
}

package pkg2023110037;

import java.sql.ResultSet;
import java.sql.SQLException;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author ASUS
 */
public class DBCO {
    private COModel dtco = new COModel();    

    public COModel getCOModel() { 
        return dtco;
    }

    public void setCOModel(COModel n) { 
        dtco = n;
    }

    public ObservableList<COModel> Load() {
        try {   
            ObservableList<COModel> TableData = FXCollections.observableArrayList();
            Koneksi con = new Koneksi(); 
            con.bukaKoneksi();
            con.statement = con.dbKoneksi.createStatement();
            ResultSet rs = con.statement.executeQuery("SELECT Tanggal_Checkout, Total, Bayar FROM hotel");
            
            while (rs.next()) {
                COModel dto = new COModel();
                dto.setTanggalCheckOut(rs.getDate("Tanggal_Checkout"));
                dto.setTotal(rs.getDouble("Total"));
                dto.setBayar(rs.getDouble("Bayar"));
                TableData.add(dto);
            }
            con.tutupKoneksi();
            return TableData;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public int validasi(String nomor) {
        int val = 0;
        try {  
            Koneksi con = new Koneksi();     
            con.bukaKoneksi();   
            con.statement = con.dbKoneksi.createStatement();
            ResultSet rs = con.statement.executeQuery("SELECT COUNT(*) AS jml FROM hotel WHERE IDPemesanan = '" + nomor + "'");
            if (rs.next()) {   
                val = rs.getInt("jml");            
            }
            con.tutupKoneksi();
        } catch (SQLException e) {            
            e.printStackTrace();        
        }
        return val;
    }

    public boolean insert() {
        boolean berhasil = false;    
        Koneksi con = new Koneksi();
        try {         
            con.bukaKoneksi();
            con.preparedStatement = con.dbKoneksi.prepareStatement("INSERT INTO hotel (Tanggal_Checkout, Total, Bayar) VALUES (?, ?, ?)");      
            con.preparedStatement.setDate(1, getCOModel().getTanggalCheckOut());
            con.preparedStatement.setDouble(2, getCOModel().getTotal());
            con.preparedStatement.setDouble(3, getCOModel().getBayar());
            con.preparedStatement.executeUpdate();
            berhasil = true;
        } catch (Exception e) {            
            e.printStackTrace();            
            berhasil = false;
        } finally {            
            con.tutupKoneksi();            
            return berhasil;        
        }
    }

    public boolean delete(String nomor) {
        boolean berhasil = false;
        Koneksi con = new Koneksi();
        try {
            con.bukaKoneksi();
            con.preparedStatement = con.dbKoneksi.prepareStatement("DELETE FROM hotel WHERE IDPemesanan = ?");
            con.preparedStatement.setString(1, nomor);
            con.preparedStatement.executeUpdate();
            berhasil = true;
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            con.tutupKoneksi();
            return berhasil;
        }
    }

    public boolean update(CIModel ciModel) {
        boolean berhasil = false;
        Koneksi con = new Koneksi();
        try {
            con.bukaKoneksi();
            con.preparedStatement = con.dbKoneksi.prepareStatement("UPDATE hotel SET Tanggal_Checkout = ?, Total = ?, Bayar = ? WHERE IDPemesanan = ?");
            con.preparedStatement.setDate(1, getCOModel().getTanggalCheckOut());
            con.preparedStatement.setDouble(2, getCOModel().getTotal());
            con.preparedStatement.setDouble(3, getCOModel().getBayar());
            con.preparedStatement.setString(4, ciModel.getIDPemesanan());
            con.preparedStatement.executeUpdate();
            berhasil = true;
        } catch (Exception e) {
            e.printStackTrace();
            berhasil = false;
        } finally {
            con.tutupKoneksi();
            return berhasil;
        }
    }
}

package pkg2023110037;

import java.net.URL;
import java.sql.Date;
import java.time.format.DateTimeFormatter;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;

/**
 * FXML Controller class
 *
 * @author ASUS
 */
public class FXML_inputcheckoutController implements Initializable {

    @FXML
    private TextField txttotal;
    @FXML
    private DatePicker dtpco;
    @FXML
    private TextField txtbayar;
    @FXML
    private Button btnsave;
    @FXML
    private Button btnclear;
    @FXML
    private Button btnexit;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
    boolean editdata = false;

    @FXML
    private void saveklik(ActionEvent event) {
        COModel n = new COModel();
        
        if (txtbayar.getText().isEmpty() || txttotal.getText().isEmpty() || dtpco.getValue() == null) {
            Alert alert = new Alert(Alert.AlertType.ERROR, "Silakan isi semua field!", ButtonType.OK);
            alert.showAndWait();
            return;
        }
        try {
            n.setBayar(Double.parseDouble(txtbayar.getText()));
            n.setTotal(Double.parseDouble(txttotal.getText()));
            n.setTanggalCheckOut(Date.valueOf(dtpco.getValue().format(DateTimeFormatter.ofPattern("yyyy-MM-dd"))));
            
            FXMLDocumentController.dtco.setCOModel(n); 

            if (editdata) {
                if (FXMLDocumentController.dtco.update(FXMLDocumentController.dtci.getCIModel())) {
                    Alert a = new Alert(Alert.AlertType.INFORMATION, "Data berhasil diubah", ButtonType.OK);
                    a.showAndWait();
                } else {
                    Alert a = new Alert(Alert.AlertType.ERROR, "Data gagal diubah", ButtonType.OK);
                    a.showAndWait();
                }
            } else {
                String totalString = String.valueOf(n.getTotal());
                if (FXMLDocumentController.dtco.validasi(totalString) <= 0) { 
                    if (FXMLDocumentController.dtco.insert()) {
                        Alert a = new Alert(Alert.AlertType.INFORMATION, "Data berhasil disimpan", ButtonType.OK);
                        a.showAndWait();
                        clearklik(event);
                    } else {
                        Alert a = new Alert(Alert.AlertType.ERROR, "Data gagal disimpan", ButtonType.OK);
                        a.showAndWait();
                    }
                } else {
                    Alert a = new Alert(Alert.AlertType.ERROR, "Data sudah ada", ButtonType.OK);
                    a.showAndWait();
                }
            }
        } catch (NumberFormatException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR, "Input tidak valid! Pastikan bayar dan total adalah angka.", ButtonType.OK);
            alert.showAndWait();
        }
    }

    @FXML
    private void clearklik(ActionEvent event) {
        txttotal.clear();
        txtbayar.clear();
        dtpco.setValue(null); 
    }

    @FXML
    private void exitklik(ActionEvent event) {
        System.exit(0);
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pkg2023110037;

import java.sql.Date;

/**
 *
 * @author ASUS
 */
public class CIModel {
    private String IDPemesanan, TipeKamar;
    private Date TanggalCheckIn;
    private int LamaMenginap;

    public String getIDPemesanan() {
        return IDPemesanan;
    }

    public void setIDPemesanan(String IDPemesanan) {
        this.IDPemesanan = IDPemesanan;
    }

    public String getTipeKamar() {
        return TipeKamar;
    }

    public void setTipeKamar(String TipeKamar) {
        this.TipeKamar = TipeKamar;
    }

    public Date getTanggalCheckIn() {
        return TanggalCheckIn;
    }

    public void setTanggalCheckIn(Date TanggalCheckIn) {
        this.TanggalCheckIn = TanggalCheckIn;
    }

    public int getLamaMenginap() {
        return LamaMenginap;
    }

    public void setLamaMenginap(int LamaMenginap) {
        this.LamaMenginap = LamaMenginap;
    }

    
    
}

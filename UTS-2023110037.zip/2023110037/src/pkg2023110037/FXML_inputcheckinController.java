/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package pkg2023110037;

import java.net.URL;
import java.sql.Date;
import java.time.format.DateTimeFormatter;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;

/**
 * FXML Controller class
 *
 * @author ASUS
 */
public class FXML_inputcheckinController implements Initializable {

    @FXML
    private TextField txtidpemesanan;
    @FXML
    private TextField txttipekamar;
    @FXML
    private TextField txtlamamenginap;
    @FXML
    private Button btnsave;
    @FXML
    private Button btnclear;
    @FXML
    private Button btnexit;
    @FXML
    private DatePicker dtpci;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void saveklik(ActionEvent event) {
        CIModel m=new CIModel();
        m.setIDPemesanan(txtidpemesanan.getText());
        m.setTipeKamar(txttipekamar.getText());
        m.setLamaMenginap(Integer.parseInt(txtlamamenginap.getText()));
        m.setTanggalCheckIn(Date.valueOf(dtpci.getValue().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")))); 
        FXMLDocumentController.dtci.setCIModel(m);
        if(FXMLDocumentController.dtci.validasi(m.getIDPemesanan())<=0){
            if(FXMLDocumentController.dtci.insert()){
               Alert a=new Alert(Alert.AlertType.INFORMATION,"Data berhasil disimpan",ButtonType.OK);
                     a.showAndWait();
                     clearklik(event);
            } else {
               Alert a=new Alert(Alert.AlertType.ERROR,"Data gagal disimpan",ButtonType.OK);
               a.showAndWait();            
            }
        }else{
            Alert a=new Alert(Alert.AlertType.ERROR,"Data sudah ada",ButtonType.OK);
            a.showAndWait();
            txtidpemesanan.requestFocus();
        }
    }

    @FXML
    private void clearklik(ActionEvent event) {
        txtidpemesanan.clear();
        txtlamamenginap.clear();
        txttipekamar.clear();
        dtpci.setValue(null); 
    }

    @FXML
    private void exitklik(ActionEvent event) {
        System.exit(0);
    }
    
}
